// src/game/levelPatterns.ts

export interface Brick {
  x: number;
  y: number;
  width: number;
  height: number;
  colorIndex: number;
  hits: number;
}

export class LevelPatterns {
  private width: number;
  private height: number;

  // مقاسات افتراضية للطوب
  private brickW: number = 46;
  private brickH: number = 20;
  private pad: number = 4;

  constructor(canvasWidth: number, canvasHeight: number) {
    this.width = canvasWidth;
    this.height = canvasHeight;
  }

  getPattern(level: number): Brick[] {
    const map: { [k: number]: (lvl: number) => Brick[] } = {
      1: (l) => this.rectangle(l),
      2: (l) => this.triangle(l),
      3: (l) => this.heart(l),
      4: (l) => this.diamond(l),
      5: (l) => this.circleRing(l),
      6: (l) => this.zigzag(l),
      7: (l) => this.star(l),
      8: (l) => this.cross(l),
      9: (l) => this.hexagonHoney(l),
      10: (l) => this.spiral(l),
      11: (l) => this.checker(l),
      12: (l) => this.arrowUp(l),
      13: (l) => this.wave(l),
      14: (l) => this.flower(l),
      15: (l) => this.crown(l),
      16: (l) => this.rocket(l),
      17: (l) => this.moon(l),
      18: (l) => this.infinity(l),
      19: (l) => this.castle(l),
      20: (l) => this.trophy(l),
    };

    return (map[level] || this.rectangle).call(this, level);
  }

  private hitsByLevel(level: number) {
    return Math.min(3, 1 + Math.floor((level - 1) / 5));
  }

  private addBrick(x: number, y: number, colorIndex: number, level: number): Brick {
    return {
      x,
      y,
      width: this.brickW - this.pad,
      height: this.brickH,
      colorIndex: ((colorIndex % 6) + 6) % 6,
      hits: this.hitsByLevel(level),
    };
  }

  // 1) مستطيل
  private rectangle(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cols = Math.max(6, Math.floor(this.width / this.brickW) - 1);
    const rows = 5;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      }
    }
    return bricks;
  }

  // 2) مثلث
  private triangle(level: number): Brick[] {
    const bricks: Brick[] = [];
    const rows = 7;
    const startY = 60;

    for (let r = 0; r < rows; r++) {
      const cols = rows - r;
      const rowW = cols * this.brickW;
      const startX = (this.width - rowW) / 2;
      for (let c = 0; c < cols; c++) {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r, level));
      }
    }
    return bricks;
  }

  // 3) قلب
  private heart(level: number): Brick[] {
    const bricks: Brick[] = [];
    const pattern: [number, number][] = [
      [0,2],[1,1],[2,0],[3,0],[4,1],[5,2],
      [0,3],[1,2],[2,1],[3,1],[4,2],[5,3],
      [0,4],[1,3],[2,2],[3,2],[4,3],[5,4],
      [1,4],[2,3],[3,3],[4,4],
      [2,4],[3,4],
    ];
    const cols = 6;
    const rowH = this.brickH + this.pad;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    pattern.forEach(([c, r], i) => {
      bricks.push(this.addBrick(startX + c * this.brickW, startY + r * rowH, r + c, level));
    });
    return bricks;
  }

  // 4) ماسة
  private diamond(level: number): Brick[] {
    const bricks: Brick[] = [];
    const size = 7;
    const startY = 60;
    for (let r = 0; r < size; r++) {
      const count = r <= Math.floor(size / 2) ? r + 1 : size - r;
      const rowW = count * this.brickW;
      const startX = (this.width - rowW) / 2;
      for (let c = 0; c < count; c++) {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      }
    }
    return bricks;
  }

  // 5) حلقة دائرية
  private circleRing(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cx = this.width / 2;
    const cy = 150;
    const radius = 100;
    const count = 22;

    for (let i = 0; i < count; i++) {
      const ang = (i / count) * Math.PI * 2;
      const x = cx + Math.cos(ang) * radius - this.brickW / 2;
      const y = cy + Math.sin(ang) * radius - this.brickH / 2;
      bricks.push(this.addBrick(x, y, i, level));
    }
    return bricks;
  }

  // 6) زجزاج
  private zigzag(level: number): Brick[] {
    const bricks: Brick[] = [];
    const rows = 6;
    const cols = Math.max(6, Math.floor(this.width / this.brickW) - 1);
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    for (let r = 0; r < rows; r++) {
      const off = (r % 2) * (this.brickW / 2);
      for (let c = 0; c < cols; c++) {
        bricks.push(this.addBrick(startX + off + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      }
    }
    return bricks;
  }

  // 7) نجمة
  private star(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cx = this.width / 2;
    const cy = 140;
    const outR = 90;
    const inR = 45;
    const spikes = 5;

    for (let i = 0; i < spikes * 2; i++) {
      const r = (i % 2 === 0) ? outR : inR;
      const ang = (i / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const x = cx + Math.cos(ang) * r - this.brickW / 2;
      const y = cy + Math.sin(ang) * r - this.brickH / 2;
      bricks.push(this.addBrick(x, y, i, level));
    }
    // وصلات إضافية
    for (let i = 0; i < spikes; i++) {
      const a1 = ((i * 2) / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const a2 = (((i * 2 + 1)) / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const midR = (outR + inR) / 2;
      const x = cx + Math.cos((a1 + a2) / 2) * midR - this.brickW / 2;
      const y = cy + Math.sin((a1 + a2) / 2) * midR - this.brickH / 2;
      bricks.push(this.addBrick(x, y, i + 10, level));
    }
    return bricks;
  }

  // 8) صليب
  private cross(level: number): Brick[] {
    const bricks: Brick[] = [];
    const size = 7;
    const startY = 60;
    const totalW = size * this.brickW;
    const startX = (this.width - totalW) / 2;
    const mid = Math.floor(size / 2);

    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (r === mid || c === mid) {
          bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
        }
      }
    }
    return bricks;
  }

  // 9) خلية سداسية مبسطة
  private hexagonHoney(level: number): Brick[] {
    const bricks: Brick[] = [];
    const rows = 6;
    const cols = 7;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    for (let r = 0; r < rows; r++) {
      const off = (r % 2) * (this.brickW / 2);
      for (let c = 0; c < cols; c++) {
        bricks.push(this.addBrick(startX + off + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      }
    }
    return bricks;
  }

  // 10) حلزوني
  private spiral(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cx = this.width / 2;
    const cy = 150;
    const steps = 28;
    for (let i = 0; i < steps; i++) {
      const ang = i * 0.45;
      const r = 10 + i * 4;
      const x = cx + Math.cos(ang) * r - this.brickW / 2;
      const y = cy + Math.sin(ang) * r - this.brickH / 2;
      bricks.push(this.addBrick(x, y, i, level));
    }
    return bricks;
  }

  // 11) رقعة شطرنج
  private checker(level: number): Brick[] {
    const bricks: Brick[] = [];
    const rows = 6;
    const cols = Math.max(6, Math.floor(this.width / this.brickW) - 1);
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if ((r + c) % 2 === 0) {
          bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
        }
      }
    }
    return bricks;
  }

  // 12) سهم للأعلى
  private arrowUp(level: number): Brick[] {
    const bricks: Brick[] = [];
    const pattern = [
      [3],
      [2,3,4],
      [1,2,3,4,5],
      [0,1,2,3,4,5,6],
      [3],
      [3],
    ];
    const cols = 7;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    pattern.forEach((arr, r) => {
      arr.forEach((c) => {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      });
    });
    return bricks;
  }

  // 13) موجة
  private wave(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cols = Math.max(8, Math.floor(this.width / this.brickW));
    const rows = 5;
    const startX = (this.width - cols * this.brickW) / 2;
    const baseY = 70;

    for (let c = 0; c < cols; c++) {
      const offset = Math.round(Math.sin(c * 0.7) * 2 + 2); // 0..4
      for (let r = 0; r < rows - Math.abs(2 - offset); r++) {
        bricks.push(this.addBrick(startX + c * this.brickW, baseY + (r + offset) * (this.brickH + this.pad), r + c, level));
      }
    }
    return bricks;
  }

  // 14) زهرة
  private flower(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cx = this.width / 2;
    const cy = 140;
    const petals = 6;
    const petalR = 70;

    bricks.push(this.addBrick(cx - this.brickW / 2, cy - this.brickH / 2, 0, level));
    for (let i = 0; i < petals; i++) {
      const ang = (i / petals) * Math.PI * 2;
      for (let j = 1; j <= 3; j++) {
        const x = cx + Math.cos(ang) * (petalR * j / 3) - this.brickW / 2;
        const y = cy + Math.sin(ang) * (petalR * j / 3) - this.brickH / 2;
        bricks.push(this.addBrick(x, y, i + j, level));
      }
    }
    return bricks;
  }

  // 15) تاج
  private crown(level: number): Brick[] {
    const bricks: Brick[] = [];
    const pattern = [
      [1,2,3,4,5],
      [0,1,2,3,4,5,6],
      [0,2,4,6],
      [0,2,4,6],
      [0,1,2,3,4,5,6],
    ];
    const cols = 7;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    pattern.forEach((arr, r) => {
      arr.forEach((c) => {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      });
    });
    return bricks;
  }

  // 16) صاروخ
  private rocket(level: number): Brick[] {
    const bricks: Brick[] = [];
    const pattern = [
      [3],
      [2,3,4],
      [2,3,4],
      [1,2,3,4,5],
      [1,2,3,4,5],
      [2,3,4],
      [2,3,4],
      [1,4],
      [0,5],
    ];
    const cols = 6;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 40;

    pattern.forEach((arr, r) => {
      arr.forEach((c) => {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      });
    });
    return bricks;
  }

  // 17) هلال
  private moon(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cx = this.width / 2;
    const cy = 140;
    const radius = 90;
    const count = 24;

    for (let i = 0; i < count; i++) {
      const ang = (i / count) * Math.PI * 2;
      if (ang > Math.PI * 0.3 && ang < Math.PI * 1.7) {
        const x = cx + Math.cos(ang) * radius - this.brickW / 2;
        const y = cy + Math.sin(ang) * radius - this.brickH / 2;
        bricks.push(this.addBrick(x, y, i, level));
      }
    }
    return bricks;
  }

  // 18) رمز اللانهائية
  private infinity(level: number): Brick[] {
    const bricks: Brick[] = [];
    const cx = this.width / 2;
    const cy = 150;
    const scale = 60;
    const points = 34;

    for (let i = 0; i < points; i++) {
      const t = (i / points) * Math.PI * 2;
      const x = cx + Math.sin(t) * scale - this.brickW / 2;
      const y = cy + (Math.sin(t) * Math.cos(t)) * scale - this.brickH / 2;
      bricks.push(this.addBrick(x, y, i, level));
    }
    return bricks;
  }

  // 19) قلعة
  private castle(level: number): Brick[] {
    const bricks: Brick[] = [];
    const pattern = [
      [0,2,4,6],
      [0,1,2,3,4,5,6],
      [0,1,2,3,4,5,6],
      [1,2,3,4,5],
      [1,2,3,4,5],
      [1,2,3,4,5],
      [0,1,2,3,4,5,6],
    ];
    const cols = 7;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 60;

    pattern.forEach((arr, r) => {
      arr.forEach((c) => {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      });
    });
    return bricks;
  }

  // 20) كأس
  private trophy(level: number): Brick[] {
    const bricks: Brick[] = [];
    const pattern = [
      [2,3,4],
      [1,2,3,4,5],
      [0,1,2,3,4,5,6],
      [1,2,3,4,5],
      [2,3,4],
      [2,3,4],
      [1,2,3,4,5],
      [0,1,2,3,4,5,6],
    ];
    const cols = 7;
    const startX = (this.width - cols * this.brickW) / 2;
    const startY = 50;

    pattern.forEach((arr, r) => {
      arr.forEach((c) => {
        bricks.push(this.addBrick(startX + c * this.brickW, startY + r * (this.brickH + this.pad), r + c, level));
      });
    });
    return bricks;
  }
}