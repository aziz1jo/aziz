// src/game/GameEngine.ts

import { LevelPatterns, Brick } from './levelPatterns';
import AudioManager from '../utils/audio';
import { Difficulty } from '../utils/storage';

export interface Ball {
  x: number;
  y: number;
  radius: number;
  velocityX: number;
  velocityY: number;
  onFire: boolean;
}

export interface Paddle {
  x: number;
  y: number;
  width: number;
  height: number;
  baseWidth: number;
}

export interface PowerUp {
  x: number;
  y: number;
  size: number;
  type: string;
  velocityY: number;
  emoji: string;
  color: string;
}

export interface Particle {
  x: number;
  y: number;
  velocityX: number;
  velocityY: number;
  size: number;
  color: string;
  life: number;
}

export class GameEngine {
  width: number;
  height: number;
  
  paddle: Paddle;
  balls: Ball[] = [];
  bricks: Brick[] = [];
  powerUps: PowerUp[] = [];
  particles: Particle[] = [];
  
  score: number = 0;
  level: number = 1;
  lives: number = 3;
  difficulty: Difficulty = 'medium';
  
  activePowers: Set<string> = new Set();
  levelPatterns: LevelPatterns;
  hasShield: boolean = false;
  
  private speedMultipliers = {
    easy: 0.5,
    medium: 1.0,
    hard: 1.8,
  };
  
  constructor(width: number, height: number, difficulty: Difficulty = 'medium') {
    this.width = width;
    this.height = height;
    this.difficulty = difficulty;
    this.levelPatterns = new LevelPatterns(width, height);
    
    const paddleWidth = 80;
    this.paddle = {
      x: width / 2 - paddleWidth / 2,
      y: height - 50,
      width: paddleWidth,
      height: 12,
      baseWidth: paddleWidth,
    };
    
    this.initLevel();
  }

  getBaseSpeed(): number {
    const baseSpeed = 6;
    const levelBonus = Math.min(this.level * 0.15, 3);
    return (baseSpeed + levelBonus) * this.speedMultipliers[this.difficulty];
  }

  initLevel() {
    const baseSpeed = this.getBaseSpeed();
    const speedX = (Math.random() - 0.5) * baseSpeed;
    const speedY = -(Math.random() * 2 + baseSpeed - 1);
    
    this.balls = [{
      x: this.width / 2,
      y: this.height - 70,
      radius: 6,
      velocityX: speedX,
      velocityY: speedY,
      onFire: false,
    }];

    this.bricks = this.levelPatterns.getPattern(this.level);
    
    this.powerUps = [];
    this.particles = [];
    this.activePowers.clear();
    this.hasShield = false;
    
    this.paddle.width = this.paddle.baseWidth;
    this.paddle.x = this.width / 2 - this.paddle.baseWidth / 2;
  }

  update(deltaTime: number) {
    this.updateBalls(deltaTime);
    this.updatePowerUps(deltaTime);
    this.updateParticles(deltaTime);
  }

  updateBalls(deltaTime: number) {
    for (let i = this.balls.length - 1; i >= 0; i--) {
      const ball = this.balls[i];
      
      ball.x += ball.velocityX;
      ball.y += ball.velocityY;

      if (ball.x - ball.radius < 0 || ball.x + ball.radius > this.width) {
        ball.velocityX *= -1;
        ball.x = ball.x < this.width / 2 ? ball.radius : this.width - ball.radius;
        AudioManager.playPaddleHit();
        this.createParticles(ball.x, ball.y, '#00f0ff', 3);
      }

      if (ball.y - ball.radius < 0) {
        ball.velocityY *= -1;
        ball.y = ball.radius;
        AudioManager.playPaddleHit();
        this.createParticles(ball.x, ball.y, '#00f0ff', 3);
      }

      // فحص السقوط - مع الدرع
      if (ball.y - ball.radius > this.height) {
        if (this.hasShield) {
          // الدرع ينقذ الكرة
          ball.y = this.height - ball.radius;
          ball.velocityY = -Math.abs(ball.velocityY);
          this.createParticles(ball.x, this.height - 10, '#00ff88', 15);
          AudioManager.playPowerUp();
        } else {
          this.balls.splice(i, 1);
          if (this.balls.length === 0) {
            this.loseLife();
          }
        }
        continue;
      }

      this.checkPaddleCollision(ball);
      this.checkBrickCollisions(ball);
    }
  }

  checkPaddleCollision(ball: Ball) {
    if (
      ball.y + ball.radius >= this.paddle.y &&
      ball.y - ball.radius <= this.paddle.y + this.paddle.height &&
      ball.x >= this.paddle.x &&
      ball.x <= this.paddle.x + this.paddle.width
    ) {
      const hitPos = (ball.x - this.paddle.x) / this.paddle.width;
      const angle = (hitPos - 0.5) * Math.PI * 0.7;
      const speed = Math.sqrt(ball.velocityX ** 2 + ball.velocityY ** 2);
      
      ball.velocityX = speed * Math.sin(angle);
      ball.velocityY = -Math.abs(speed * Math.cos(angle));
      ball.y = this.paddle.y - ball.radius;

      AudioManager.playPaddleHit();
      this.createParticles(ball.x, this.paddle.y, '#667eea', 5);
    }
  }

  checkBrickCollisions(ball: Ball) {
    for (let i = this.bricks.length - 1; i >= 0; i--) {
      const brick = this.bricks[i];

      if (this.isColliding(ball, brick)) {
        // إذا كانت الكرة نار - لا ترتد فقط اختراق!
        if (!ball.onFire) {
          const prevX = ball.x - ball.velocityX;
          const prevY = ball.y - ball.velocityY;

          if (prevX < brick.x || prevX > brick.x + brick.width) {
            ball.velocityX *= -1;
          } else {
            ball.velocityY *= -1;
          }
        }

        brick.hits--;

        if (brick.hits <= 0) {
          this.destroyBrick(i, brick);
        } else {
          AudioManager.playBrickHit();
        }

        // إذا لم تكن نار، توقف عند أول طوبة
        if (!ball.onFire) break;
      }
    }
  }

  isColliding(ball: Ball, brick: Brick): boolean {
    return (
      ball.x + ball.radius >= brick.x &&
      ball.x - ball.radius <= brick.x + brick.width &&
      ball.y + ball.radius >= brick.y &&
      ball.y - ball.radius <= brick.y + brick.height
    );
  }

  destroyBrick(index: number, brick: Brick) {
    const centerX = brick.x + brick.width / 2;
    const centerY = brick.y + brick.height / 2;

    this.createParticles(centerX, centerY, '#00f0ff', 8);
    this.bricks.splice(index, 1);

    const points = 10 * this.level;
    this.score += points;

    if (Math.random() < 0.18) {
      this.createPowerUp(centerX, centerY);
    }

    AudioManager.playBrickBreak();
  }

  updatePowerUps(deltaTime: number) {
    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      const power = this.powerUps[i];
      power.y += power.velocityY;

      if (this.isCollidingWithPaddle(power)) {
        this.activatePower(power.type);
        this.powerUps.splice(i, 1);
        continue;
      }

      if (power.y > this.height) {
        this.powerUps.splice(i, 1);
      }
    }
  }

  isCollidingWithPaddle(power: PowerUp): boolean {
    return (
      power.y + power.size / 2 >= this.paddle.y &&
      power.y - power.size / 2 <= this.paddle.y + this.paddle.height &&
      power.x + power.size / 2 >= this.paddle.x &&
      power.x - power.size / 2 <= this.paddle.x + this.paddle.width
    );
  }

  createPowerUp(x: number, y: number) {
    const types = [
      { type: 'expand', emoji: '↔', color: '#4ECDC4' },
      { type: 'slow', emoji: '◷', color: '#FFD93D' },
      { type: 'fire', emoji: '☄', color: '#FF4500' },
      { type: 'multi', emoji: '◎', color: '#9D50BB' },
      { type: 'shrink', emoji: '↕', color: '#FF6B6B' },
      { type: 'fast', emoji: '⚡', color: '#00FF88' },
      { type: 'shield', emoji: '⊞', color: '#00FF88' },
    ];

    const power = types[Math.floor(Math.random() * types.length)];

    // كل الصناديق بنفس اللون!
    this.powerUps.push({
      x,
      y,
      size: 28,
      type: power.type,
      velocityY: 2.5,
      emoji: '◆', // شكل موحد
      color: '#FFD700', // لون ذهبي موحد
    });
  }

  activatePower(type: string) {
    AudioManager.playPowerUp();
    this.createParticles(this.paddle.x + this.paddle.width / 2, this.paddle.y, '#ffd700', 20);

    switch (type) {
      case 'expand':
        if (this.activePowers.has('shrink')) {
          this.activePowers.delete('shrink');
        }
        
        this.paddle.width = this.paddle.baseWidth * 1.7;
        this.activePowers.add('expand');
        
        setTimeout(() => {
          if (this.activePowers.has('expand')) {
            this.paddle.width = this.paddle.baseWidth;
            this.activePowers.delete('expand');
          }
        }, 8000);
        break;

      case 'shrink':
        if (this.activePowers.has('expand')) {
          this.activePowers.delete('expand');
        }
        
        this.paddle.width = this.paddle.baseWidth * 0.5;
        this.activePowers.add('shrink');
        
        setTimeout(() => {
          if (this.activePowers.has('shrink')) {
            this.paddle.width = this.paddle.baseWidth;
            this.activePowers.delete('shrink');
          }
        }, 6000);
        break;

      case 'slow':
        this.balls.forEach(b => {
          b.velocityX *= 0.5;
          b.velocityY *= 0.5;
        });
        this.activePowers.add('slow');
        
        setTimeout(() => {
          if (this.activePowers.has('slow')) {
            this.balls.forEach(b => {
              b.velocityX *= 2;
              b.velocityY *= 2;
            });
            this.activePowers.delete('slow');
          }
        }, 7000);
        break;

      case 'fast':
        this.balls.forEach(b => {
          b.velocityX *= 1.6;
          b.velocityY *= 1.6;
        });
        this.activePowers.add('fast');
        
        setTimeout(() => {
          if (this.activePowers.has('fast')) {
            this.balls.forEach(b => {
              b.velocityX *= 0.625;
              b.velocityY *= 0.625;
            });
            this.activePowers.delete('fast');
          }
        }, 5000);
        break;

      case 'fire':
        this.balls.forEach(b => (b.onFire = true));
        this.activePowers.add('fire');
        
        setTimeout(() => {
          if (this.activePowers.has('fire')) {
            this.balls.forEach(b => (b.onFire = false));
            this.activePowers.delete('fire');
          }
        }, 10000);
        break;

      case 'shield':
        // الدرع - المضرب يصبح بعرض الشاشة!
        this.paddle.x = 0;
        this.paddle.width = this.width;
        this.hasShield = true;
        this.activePowers.add('shield');
        
        setTimeout(() => {
          if (this.activePowers.has('shield')) {
            this.paddle.width = this.paddle.baseWidth;
            this.paddle.x = this.width / 2 - this.paddle.baseWidth / 2;
            this.hasShield = false;
            this.activePowers.delete('shield');
          }
        }, 8000);
        break;

      case 'multi':
        const current = [...this.balls].slice(0, 3);
        current.forEach(ball => {
          this.balls.push({
            x: ball.x,
            y: ball.y,
            radius: ball.radius,
            velocityX: ball.velocityX * 1.2 + (Math.random() - 0.5) * 3,
            velocityY: ball.velocityY,
            onFire: ball.onFire,
          });
          this.balls.push({
            x: ball.x,
            y: ball.y,
            radius: ball.radius,
            velocityX: ball.velocityX * 0.8 + (Math.random() - 0.5) * 3,
            velocityY: ball.velocityY,
            onFire: ball.onFire,
          });
        });
        break;
    }
  }

  updateParticles(deltaTime: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.velocityX;
      p.y += p.velocityY;
      p.velocityY += 0.3;
      p.life--;

      if (p.life <= 0) {
        this.particles.splice(i, 1);
      }
    }
  }

  createParticles(x: number, y: number, color: string, count: number) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x,
        y,
        velocityX: (Math.random() - 0.5) * 6,
        velocityY: (Math.random() - 0.5) * 6 - 2,
        size: Math.random() * 4 + 2,
        color,
        life: 40,
      });
    }
  }

  movePaddle(targetX: number) {
    // إذا كان الدرع نشط، المضرب لا يتحرك
    if (this.hasShield) return;
    
    this.paddle.x = Math.max(0, Math.min(targetX, this.width - this.paddle.width));
  }

  loseLife() {
    this.lives--;
    AudioManager.playLoseLife();

    if (this.lives <= 0) {
      return 'gameOver';
    }

    const baseSpeed = this.getBaseSpeed();
    const speedX = (Math.random() - 0.5) * baseSpeed;
    const speedY = -(Math.random() * 2 + baseSpeed - 1);
    
    this.balls = [{
      x: this.width / 2,
      y: this.height - 70,
      radius: 6,
      velocityX: speedX,
      velocityY: speedY,
      onFire: false,
    }];

    this.activePowers.clear();
    this.hasShield = false;
    this.paddle.width = this.paddle.baseWidth;

    return 'continue';
  }

  checkWin(): boolean {
    return this.bricks.length === 0;
  }

  nextLevel() {
    this.level++;
    this.initLevel();
  }

  getStats() {
    return {
      score: this.score,
      level: this.level,
      lives: this.lives,
      bricksRemaining: this.bricks.length,
    };
  }
}