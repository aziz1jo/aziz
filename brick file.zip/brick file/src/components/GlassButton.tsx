// src/components/GlassButton.tsx

import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ViewStyle, TextStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Sizes, Shadows } from '../utils/theme';

interface GlassButtonProps {
  title: string;
  onPress: () => void;
  icon?: string;
  variant?: 'primary' | 'secondary';
  style?: ViewStyle;
  disabled?: boolean;
}

export default function GlassButton({ 
  title, 
  onPress, 
  icon, 
  variant = 'secondary',
  style,
  disabled = false 
}: GlassButtonProps) {
  
  const isPrimary = variant === 'primary';
  
  if (isPrimary) {
    return (
      <TouchableOpacity 
        onPress={onPress} 
        disabled={disabled}
        activeOpacity={0.8}
        style={[styles.button, style, disabled && styles.disabled]}
      >
        <LinearGradient
          colors={['#00f0ff', '#ff00ff']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.gradient}
        >
          {icon && <Text style={styles.icon}>{icon}</Text>}
          <Text style={styles.primaryText}>{title}</Text>
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity 
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.8}
      style={[styles.button, styles.glassButton, style, disabled && styles.disabled]}
    >
      {icon && <Text style={styles.icon}>{icon}</Text>}
      <Text style={styles.secondaryText}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: Sizes.radiusLg,
    overflow: 'hidden',
    marginVertical: Sizes.sm,
  },
  gradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Sizes.md,
    paddingHorizontal: Sizes.lg,
    gap: Sizes.sm,
  },
  glassButton: {
    backgroundColor: Colors.glass,
    borderWidth: 1,
    borderColor: Colors.glassBorder,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Sizes.md,
    paddingHorizontal: Sizes.lg,
    gap: Sizes.sm,
  },
  icon: {
    fontSize: Sizes.fontXl,
  },
  primaryText: {
    color: Colors.textPrimary,
    fontSize: Sizes.fontLg,
    fontWeight: '700',
  },
  secondaryText: {
    color: Colors.textPrimary,
    fontSize: Sizes.fontLg,
    fontWeight: '600',
  },
  disabled: {
    opacity: 0.5,
  },
});