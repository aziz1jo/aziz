// src/components/GlassCard.tsx

import React, { ReactNode } from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Colors, Sizes } from '../utils/theme';

interface GlassCardProps {
  children: ReactNode;
  style?: ViewStyle;
  glow?: boolean;
  glowColor?: string;
}

export default function GlassCard({ 
  children, 
  style, 
  glow = false,
  glowColor = Colors.primary 
}: GlassCardProps) {
  return (
    <View 
      style={[
        styles.card, 
        style,
        glow && {
          shadowColor: glowColor,
          shadowOffset: { width: 0, height: 0 },
          shadowOpacity: 0.8,
          shadowRadius: 15,
          elevation: 10,
        }
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.glass,
    borderRadius: Sizes.radiusLg,
    borderWidth: 1,
    borderColor: Colors.glassBorder,
    padding: Sizes.md,
  },
});