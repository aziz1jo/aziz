// src/screens/LoaderScreen.tsx

import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Sizes } from '../utils/theme';

const { width } = Dimensions.get('window');

interface LoaderScreenProps {
  onFinish: () => void;
}

export default function LoaderScreen({ onFinish }: LoaderScreenProps) {
  const progressAnim = new Animated.Value(0);
  const rotateAnim = new Animated.Value(0);

  useEffect(() => {
    // أنيميشن التحميل
    Animated.timing(progressAnim, {
      toValue: 100,
      duration: 2000,
      useNativeDriver: false,
    }).start(() => {
      setTimeout(onFinish, 300);
    });

    // أنيميشن الدوران
    Animated.loop(
      Animated.timing(rotateAnim, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: true,
      })
    ).start();
  }, []);

  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const rotate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  return (
    <LinearGradient
      colors={['#0a0a1f', '#1a1a3e']}
      style={styles.container}
    >
      {/* شعار اللعبة */}
      <View style={styles.logoContainer}>
        <Animated.View style={[styles.ring, { transform: [{ rotate }] }]}>
          <View style={styles.ringInner} />
        </Animated.View>
        
        <Text style={styles.title}>BRICK</Text>
        <Text style={styles.title}>BREAKER</Text>
        <Text style={styles.subtitle}>3D ULTRA</Text>
      </View>

      {/* شريط التقدم */}
      <View style={styles.progressContainer}>
        <Text style={styles.loadingText}>جاري التحميل...</Text>
        
        <View style={styles.progressBar}>
          <Animated.View 
            style={[styles.progressFill, { width: progressWidth }]} 
          />
        </View>
        
        <Animated.Text style={styles.percentage}>
          {progressAnim.interpolate({
            inputRange: [0, 100],
            outputRange: ['0%', '100%'],
          })}
        </Animated.Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: Sizes.xl,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: Sizes.xxl * 2,
  },
  ring: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 4,
    borderColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Sizes.xl,
  },
  ringInner: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: Colors.secondary,
  },
  title: {
    fontSize: Sizes.fontTitle,
    fontWeight: '900',
    color: Colors.primary,
    textShadowColor: Colors.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
    letterSpacing: 2,
  },
  subtitle: {
    fontSize: Sizes.fontLg,
    color: Colors.accent,
    marginTop: Sizes.sm,
    letterSpacing: 5,
  },
  progressContainer: {
    width: '100%',
    maxWidth: 300,
    alignItems: 'center',
  },
  loadingText: {
    color: Colors.textPrimary,
    fontSize: Sizes.fontMd,
    marginBottom: Sizes.md,
  },
  progressBar: {
    width: '100%',
    height: 6,
    backgroundColor: Colors.glass,
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.glassBorder,
  },
  progressFill: {
    height: '100%',
    backgroundColor: Colors.primary,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 10,
  },
  percentage: {
    color: Colors.primary,
    fontSize: Sizes.fontMd,
    fontWeight: 'bold',
    marginTop: Sizes.md,
  },
});