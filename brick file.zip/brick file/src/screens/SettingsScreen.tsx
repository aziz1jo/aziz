// src/screens/SettingsScreen.tsx

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import Slider from '@react-native-community/slider';
import GlassButton from '../components/GlassButton';
import GlassCard from '../components/GlassCard';
import Storage, { Difficulty } from '../utils/storage';
import AudioManager from '../utils/audio';
import I18n, { Language } from '../utils/i18n';
import { Colors, Sizes } from '../utils/theme';

interface SettingsScreenProps {
  onBack: () => void;
  onLanguageChange: () => void;
}

export default function SettingsScreen({ onBack, onLanguageChange }: SettingsScreenProps) {
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [vibrationEnabled, setVibrationEnabled] = useState(true);
  const [musicVolume, setMusicVolume] = useState(0.7);
  const [vibrationIntensity, setVibrationIntensity] = useState(1.0);
  const [language, setLanguage] = useState<Language>('ar');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [animationValue, setAnimationValue] = useState(0);
  
  useEffect(() => {
    // رسوم متحركة بسيطة عند تحميل الشاشة
    setAnimationValue(0);
    setTimeout(() => {
      setAnimationValue(1);
    }, 300);
  }, []);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const sound = await Storage.getSoundEnabled();
    const vibration = await Storage.getVibrationEnabled();
    const volume = await Storage.getMusicVolume();
    const intensity = await Storage.getVibrationIntensity();
    const lang = await Storage.getLanguage() as Language;
    const diff = await Storage.getDifficulty();

    setSoundEnabled(sound);
    setVibrationEnabled(vibration);
    setMusicVolume(volume);
    setVibrationIntensity(intensity);
    setLanguage(lang);
    setDifficulty(diff);

    I18n.setLanguage(lang);
  };

  const handleSoundToggle = async (value: boolean) => {
    setSoundEnabled(value);
    await Storage.saveSoundEnabled(value);
    await AudioManager.toggleSound();
    if (value) AudioManager.playPowerUp();
  };

  const handleVibrationToggle = async (value: boolean) => {
    setVibrationEnabled(value);
    await Storage.saveVibrationEnabled(value);
    await AudioManager.toggleVibration();
    if (value) AudioManager.vibrate('success');
  };

  const handleMusicVolumeChange = async (value: number) => {
    setMusicVolume(value);
    await Storage.saveMusicVolume(value);
  };

  const handleVibrationIntensityChange = async (value: number) => {
    setVibrationIntensity(value);
    await AudioManager.setVibrationIntensity(value);
    await Storage.saveVibrationIntensity(value);
  };

  const handleLanguageChange = async (lang: Language) => {
    setLanguage(lang);
    await Storage.saveLanguage(lang);
    I18n.setLanguage(lang);
    onLanguageChange();
  };

  const handleDifficultyChange = async (diff: Difficulty) => {
    setDifficulty(diff);
    await Storage.saveDifficulty(diff);
    AudioManager.playPowerUp();
  };

  const getVolumeLabel = (volume: number) => {
    if (volume === 0) return I18n.t('muted') || 'كتم';
    if (volume < 0.3) return I18n.t('low') || 'منخفض';
    if (volume < 0.7) return I18n.t('medium') || 'متوسط';
    return I18n.t('high') || 'عالي';
  };

  return (
    <LinearGradient colors={['#0a0a1f', '#1a1a3e']} style={styles.container}>
      <StatusBar style="light" />
      
      <View style={[styles.header, { opacity: animationValue }]}>
        <Text style={[styles.title, { transform: [{ translateY: animationValue === 0 ? 20 : 0 }] }]}>{I18n.t('settingsTitle')}</Text>
      </View>

      <ScrollView 
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* الصوت والموسيقى */}
        <Text style={styles.sectionTitle}>♫ {I18n.t('sound')}</Text>
        
        <GlassCard style={styles.settingCard}>
          <View style={styles.settingRow}>
            <Text style={styles.settingLabel}>{I18n.t('sound')}</Text>
            <Switch
              value={soundEnabled}
              onValueChange={handleSoundToggle}
              trackColor={{ false: '#444', true: Colors.primary }}
              thumbColor={soundEnabled ? Colors.accent : '#888'}
            />
          </View>
        </GlassCard>

        <GlassCard style={styles.settingCard}>
          <View style={styles.settingColumn}>
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>{I18n.t('volume')}</Text>
              <Text style={styles.volumeLabel}>{getVolumeLabel(musicVolume)}</Text>
            </View>
            <Slider
              style={styles.slider}
              minimumValue={0}
              maximumValue={1}
              value={musicVolume}
              onValueChange={handleMusicVolumeChange}
              minimumTrackTintColor={Colors.primary}
              maximumTrackTintColor="#444"
              thumbTintColor={Colors.accent}
              disabled={!soundEnabled}
            />
            <View style={styles.sliderLabels}>
              <Text style={styles.sliderLabel}>◧</Text>
              <Text style={styles.sliderLabel}>◨</Text>
            </View>
          </View>
        </GlassCard>

        {/* الاهتزاز */}
        <Text style={styles.sectionTitle}>〰️ {I18n.t('vibration')}</Text>
        
        <GlassCard style={styles.settingCard}>
          <View style={styles.settingRow}>
            <Text style={styles.settingLabel}>{I18n.t('vibration')}</Text>
            <Switch
              value={vibrationEnabled}
              onValueChange={handleVibrationToggle}
              trackColor={{ false: '#444', true: Colors.primary }}
              thumbColor={vibrationEnabled ? Colors.accent : '#888'}
            />
          </View>
        </GlassCard>

        <GlassCard style={styles.settingCard}>
          <View style={styles.settingColumn}>
            <View style={styles.settingRow}>
              <Text style={styles.settingLabel}>{I18n.t('intensity') || 'الشدة'}</Text>
              <Text style={styles.volumeLabel}>
                {vibrationIntensity === 0 ? (I18n.t('off') || 'متوقف') : 
                 vibrationIntensity < 0.5 ? (I18n.t('low') || 'منخفض') : 
                 vibrationIntensity < 0.8 ? (I18n.t('medium') || 'متوسط') : 
                 (I18n.t('high') || 'عالي')}
              </Text>
            </View>
            <Slider
              style={styles.slider}
              minimumValue={0}
              maximumValue={1}
              value={vibrationIntensity}
              onValueChange={handleVibrationIntensityChange}
              onSlidingComplete={(value) => {
                if (value > 0) AudioManager.vibrate('medium');
              }}
              minimumTrackTintColor={Colors.secondary}
              maximumTrackTintColor="#444"
              thumbTintColor={Colors.accent}
              disabled={!vibrationEnabled}
            />
            <View style={styles.sliderLabels}>
              <Text style={styles.sliderLabel}>ضعيف</Text>
              <Text style={styles.sliderLabel}>قوي</Text>
            </View>
          </View>
        </GlassCard>

        {/* اللغة */}
        <Text style={styles.sectionTitle}>◉ {I18n.t('language')}</Text>
        
        <View style={styles.languageButtons}>
          <TouchableOpacity
            style={[styles.languageBtn, language === 'ar' && styles.languageBtnActive]}
            onPress={() => handleLanguageChange('ar')}
          >
            <Text style={[styles.languageBtnText, language === 'ar' && styles.languageBtnTextActive]}>
              العربية
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.languageBtn, language === 'en' && styles.languageBtnActive]}
            onPress={() => handleLanguageChange('en')}
          >
            <Text style={[styles.languageBtnText, language === 'en' && styles.languageBtnTextActive]}>
              English
            </Text>
          </TouchableOpacity>
        </View>

        {/* مستوى الصعوبة */}
        <Text style={styles.sectionTitle}>⚡ {I18n.t('difficulty')}</Text>
        
        <View style={styles.difficultyButtons}>
          <TouchableOpacity
            style={[styles.difficultyBtn, difficulty === 'easy' && styles.difficultyBtnActive]}
            onPress={() => handleDifficultyChange('easy')}
          >
            <View style={styles.difficultyIcon}>
              <Text style={styles.difficultyIconText}>1</Text>
            </View>
            <Text style={[styles.difficultyBtnText, difficulty === 'easy' && styles.difficultyBtnTextActive]}>
              {I18n.t('easy')}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.difficultyBtn, difficulty === 'medium' && styles.difficultyBtnActive]}
            onPress={() => handleDifficultyChange('medium')}
          >
            <View style={styles.difficultyIcon}>
              <Text style={styles.difficultyIconText}>2</Text>
            </View>
            <Text style={[styles.difficultyBtnText, difficulty === 'medium' && styles.difficultyBtnTextActive]}>
              {I18n.t('medium')}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.difficultyBtn, difficulty === 'hard' && styles.difficultyBtnActive]}
            onPress={() => handleDifficultyChange('hard')}
          >
            <View style={[styles.difficultyIcon, styles.difficultyIconHard]}>
              <Text style={styles.difficultyIconText}>3</Text>
            </View>
            <Text style={[styles.difficultyBtnText, difficulty === 'hard' && styles.difficultyBtnTextActive]}>
              {I18n.t('hard')}
            </Text>
          </TouchableOpacity>
        </View>

        <GlassCard style={styles.infoCard}>
          <Text style={styles.infoText}>
            ◉ {language === 'ar' ? 'مستوى الصعوبة يؤثر على سرعة الكرة' : 'Difficulty affects ball speed'}
          </Text>
        </GlassCard>

        <GlassButton
          title={I18n.t('back')}
          icon="◀"
          variant="primary"
          onPress={onBack}
          style={styles.backButton}
        />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingTop: Sizes.xxl * 2,
    paddingHorizontal: Sizes.xl,
    paddingBottom: Sizes.lg,
  },
  title: {
    fontSize: Sizes.fontXxl,
    fontWeight: '900',
    color: Colors.primary,
    textAlign: 'center',
    textShadowColor: Colors.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  content: {
    padding: Sizes.xl,
    paddingTop: Sizes.md,
  },
  sectionTitle: {
    fontSize: Sizes.fontLg,
    fontWeight: '700',
    color: Colors.textPrimary,
    marginTop: Sizes.lg,
    marginBottom: Sizes.md,
  },
  settingCard: {
    marginBottom: Sizes.md,
    padding: Sizes.lg,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  settingColumn: {
    gap: Sizes.sm,
  },
  settingLabel: {
    fontSize: Sizes.fontMd,
    color: Colors.textPrimary,
    fontWeight: '600',
  },
  volumeLabel: {
    fontSize: Sizes.fontSm,
    color: Colors.primary,
    fontWeight: '700',
  },
  slider: {
    width: '100%',
    height: 40,
  },
  sliderLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: Sizes.xs,
  },
  sliderLabel: {
    fontSize: Sizes.fontSm,
    color: Colors.textSecondary,
  },
  languageButtons: {
    flexDirection: 'row',
    gap: Sizes.md,
    marginBottom: Sizes.md,
  },
  languageBtn: {
    flex: 1,
    backgroundColor: Colors.glass,
    borderWidth: 2,
    borderColor: Colors.glassBorder,
    borderRadius: Sizes.radiusLg,
    padding: Sizes.md,
    alignItems: 'center',
  },
  languageBtnActive: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primary + '20',
  },
  languageBtnText: {
    fontSize: Sizes.fontMd,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  languageBtnTextActive: {
    color: Colors.primary,
    fontWeight: '700',
  },
  difficultyButtons: {
    flexDirection: 'row',
    gap: Sizes.sm,
    marginBottom: Sizes.md,
  },
  difficultyBtn: {
    flex: 1,
    backgroundColor: Colors.glass,
    borderWidth: 2,
    borderColor: Colors.glassBorder,
    borderRadius: Sizes.radiusLg,
    padding: Sizes.md,
    alignItems: 'center',
    gap: Sizes.xs,
  },
  difficultyBtnActive: {
    borderColor: Colors.success,
    backgroundColor: Colors.success + '20',
  },
  difficultyIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.primary + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  difficultyIconHard: {
    backgroundColor: Colors.danger + '30',
  },
  difficultyIconText: {
    color: Colors.primary,
    fontSize: 20,
    fontWeight: 'bold',
  },
  difficultyBtnText: {
    fontSize: Sizes.fontSm,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  difficultyBtnTextActive: {
    color: Colors.success,
    fontWeight: '700',
  },
  infoCard: {
    padding: Sizes.md,
    marginBottom: Sizes.lg,
    backgroundColor: Colors.primary + '10',
    borderColor: Colors.primary + '40',
  },
  infoText: {
    fontSize: Sizes.fontSm,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
  },
  backButton: {
    marginTop: Sizes.md,
  },
});