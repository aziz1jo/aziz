// src/screens/GameScreen.tsx

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Dimensions, TouchableOpacity } from 'react-native';
import Svg, { Circle, Rect, Text as SvgText, Defs, LinearGradient as SvgGradient, Stop } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import { GameEngine } from '../game/GameEngine';
import GlassCard from '../components/GlassCard';
import GlassButton from '../components/GlassButton';
import Storage from '../utils/storage';
import AudioManager from '../utils/audio';
import I18n from '../utils/i18n';
import { Colors, Sizes } from '../utils/theme';

const { width, height } = Dimensions.get('window');
const CANVAS_WIDTH = Math.min(width - 24, 400);
const CANVAS_HEIGHT = CANVAS_WIDTH * 1.6;

interface GameScreenProps {
  initialLevel?: number;
  onExit: () => void;
}

interface BackgroundParticle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  opacity: number;
}

export default function GameScreen({ initialLevel = 1, onExit }: GameScreenProps) {
  const [isPaused, setIsPaused] = useState(false);
  const [showWin, setShowWin] = useState(false);
  const [showLose, setShowLose] = useState(false);
  const [overlayAnimation, setOverlayAnimation] = useState({ opacity: 0, scale: 0.8 });
  const [stats, setStats] = useState({ score: 0, level: 1, lives: 3, bricksRemaining: 0 });
  const [bgParticles, setBgParticles] = useState<BackgroundParticle[]>([]);
  const [forceUpdate, setForceUpdate] = useState(0);
  
  const engineRef = useRef<GameEngine | null>(null);
  const animationRef = useRef<number>();
  const lastTouchX = useRef<number>(CANVAS_WIDTH / 2);
  const canUpdate = useRef<boolean>(true);

  useEffect(() => {
    initBackground();
    initEngine();
    return () => { if (animationRef.current) cancelAnimationFrame(animationRef.current); };
  }, []);

  const initBackground = () => {
    const arr: BackgroundParticle[] = [];
    for (let i = 0; i < 15; i++) {
      arr.push({
        x: Math.random() * CANVAS_WIDTH,
        y: Math.random() * CANVAS_HEIGHT,
        size: Math.random() * 3 + 1,
        speedY: Math.random() * 0.5 + 0.2,
        opacity: Math.random() * 0.5 + 0.3,
      });
    }
    setBgParticles(arr);
  };

  const initEngine = async () => {
    const diff = await Storage.getDifficulty();
    engineRef.current = new GameEngine(CANVAS_WIDTH, CANVAS_HEIGHT, diff);
    engineRef.current.level = initialLevel;
    engineRef.current.initLevel();
    canUpdate.current = true;
    startGameLoop();
  };

  const startGameLoop = () => {
    let lastTime = Date.now();
    let frame = 0;
    const loop = () => {
      const now = Date.now();
      const dt = (now - lastTime) / 16.67;
      lastTime = now;

      if (canUpdate.current && engineRef.current) {
        engineRef.current.update(dt);

        frame++;
        if (frame % 2 === 0) setStats(engineRef.current.getStats());
        if (frame % 5 === 0) {
          setBgParticles(prev => prev.map(p => {
            let y = p.y + p.speedY * 5;
            if (y > CANVAS_HEIGHT) y = 0;
            return { ...p, y };
          }));
        }
        if (frame % 10 === 0) setForceUpdate(v => v + 1);

        if (engineRef.current.lives <= 0) handleGameOver();
        if (engineRef.current.checkWin()) handleWin();
      }
      animationRef.current = requestAnimationFrame(loop);
    };
    loop();
  };

  const handleWin = async () => {
    canUpdate.current = false;
    // بدء الرسوم المتحركة
    setOverlayAnimation({ opacity: 0, scale: 0.8 });
    setTimeout(() => {
      setOverlayAnimation({ opacity: 1, scale: 1 });
    }, 100);
    setShowWin(true);
    AudioManager.playLevelWin();
    if (!engineRef.current) return;

    const level = engineRef.current.level;
    const score = engineRef.current.score;

    const hs = await Storage.getHighScore();
    if (score > hs) await Storage.saveHighScore(score);

    const hl = await Storage.getHighLevel();
    if (level >= hl) await Storage.saveHighLevel(level + 1);

    const completed = await Storage.getCompletedLevels();
    if (!completed.includes(level)) {
      completed.push(level);
      await Storage.saveCompletedLevels(completed);
    }
  };

  const handleGameOver = async () => {
    canUpdate.current = false;
    // بدء الرسوم المتحركة
    setOverlayAnimation({ opacity: 0, scale: 0.8 });
    setTimeout(() => {
      setOverlayAnimation({ opacity: 1, scale: 1 });
    }, 100);
    setShowLose(true);
    AudioManager.playGameOver();
    if (!engineRef.current) return;
    const score = engineRef.current.score;
    const hs = await Storage.getHighScore();
    if (score > hs) await Storage.saveHighScore(score);
  };

  const handleNextLevel = () => {
    setShowWin(false);
    if (engineRef.current) {
      engineRef.current.level++;
      engineRef.current.initLevel();
      setStats(engineRef.current.getStats());
    }
    canUpdate.current = true;
  };

  const handleRetry = () => {
    setShowLose(false);
    if (engineRef.current) {
      engineRef.current.lives = 3;
      engineRef.current.score = 0;
      engineRef.current.initLevel();
      setStats(engineRef.current.getStats());
    }
    canUpdate.current = true;
  };

  const handleResume = () => {
    setIsPaused(false);
    canUpdate.current = true;
  };

  const handlePause = () => {
    setIsPaused(true);
    canUpdate.current = false;
  };

  const handleTouch = (e: any) => {
    if (!engineRef.current || !canUpdate.current) return;
    const x = e.nativeEvent.locationX || e.nativeEvent.pageX || 0;
    const dx = x - lastTouchX.current;
    engineRef.current.movePaddle(engineRef.current.paddle.x + dx);
    lastTouchX.current = x;
  };

  const handleTouchStart = (e: any) => {
    lastTouchX.current = e.nativeEvent.locationX || e.nativeEvent.pageX || CANVAS_WIDTH / 2;
  };

  // رسم صندوق غامض موحّد (بدون كشف النوع)
  const renderMysteryBox = (power: any, i: number) => {
    const { x, y, size } = power;
    const s = size;
    const half = s / 2;
    return (
      <React.Fragment key={`p-${i}`}>
        {/* توهج ناعم */}
        <Circle cx={x} cy={y} r={s * 0.9} fill="#FFD700" opacity={0.15} />
        <Circle cx={x} cy={y} r={s * 0.65} fill="#FFD700" opacity={0.25} />
        {/* الصندوق */}
        <Rect x={x - half} y={y - half} width={s} height={s} rx={8} ry={8} fill="#C79A00" />
        {/* ربطات هدية */}
        <Rect x={x - 3} y={y - half} width={6} height={s} fill="#FF2E63" />
        <Rect x={x - half} y={y - 3} width={s} height={6} fill="#FF2E63" />
        {/* علامة استفهام */}
        <SvgText
          x={x}
          y={y + 5}
          fill="white"
          fontSize="16"
          fontWeight="bold"
          textAnchor="middle"
        >
          ?
        </SvgText>
        {/* حد خارجي */}
        <Rect
          x={x - half}
          y={y - half}
          width={s}
          height={s}
          rx={8}
          ry={8}
          stroke="white"
          strokeWidth={2}
          fill="none"
          opacity={0.8}
        />
      </React.Fragment>
    );
  };

  const renderGame = () => {
    if (!engineRef.current) return null;
    const engine = engineRef.current;

    return (
      <Svg width={CANVAS_WIDTH} height={CANVAS_HEIGHT} onTouchMove={handleTouch} onTouchStart={handleTouchStart}>
        <Defs>
          {Colors.bricks.map((c, i) => (
            <SvgGradient key={`g-${i}`} id={`g${i}`} x1="0" y1="0" x2="1" y2="1">
              <Stop offset="0" stopColor={c[0]} stopOpacity="0.4" />
              <Stop offset="1" stopColor={c[1]} stopOpacity="0.6" />
            </SvgGradient>
          ))}
        </Defs>

        {/* خلفية */}
        <Rect x={0} y={0} width={CANVAS_WIDTH} height={CANVAS_HEIGHT} fill="rgba(0,0,0,0.2)" />
        {bgParticles.map((p, i) => <Circle key={`bg-${i}`} cx={p.x} cy={p.y} r={p.size} fill="white" opacity={p.opacity} />)}

        {/* الطوب */}
        {engine.bricks.map((b, i) => (
          <React.Fragment key={`b-${i}`}>
            <Rect x={b.x + 2} y={b.y + 2} width={b.width} height={b.height} fill="rgba(0,0,0,0.3)" rx={6} ry={6} />
            <Rect x={b.x} y={b.y} width={b.width} height={b.height} fill={`url(#g${b.colorIndex})`} rx={6} ry={6} stroke={Colors.bricks[b.colorIndex][0]} strokeWidth={2} />
            <Rect x={b.x + 2} y={b.y + 1} width={b.width - 4} height={3} fill="rgba(255,255,255,0.5)" rx={2} />
            <Rect x={b.x + 1} y={b.y + 2} width={3} height={b.height - 4} fill="rgba(255,255,255,0.3)" ry={2} />
            {b.hits > 1 && (
              <SvgText x={b.x + b.width / 2} y={b.y + b.height / 2 + 4} fontSize="12" fontWeight="bold" fill="white" textAnchor="middle">
                {b.hits}
              </SvgText>
            )}
          </React.Fragment>
        ))}

        {/* المضرب + مؤثرات عند الدرع/التوسيع/التصغير */}
        {engine.activePowers.has('expand') && (
          <Rect x={engine.paddle.x - 3} y={engine.paddle.y - 3} width={engine.paddle.width + 6} height={engine.paddle.height + 6} rx={8} fill="#4ECDC4" opacity={0.35} />
        )}
        {engine.activePowers.has('shrink') && (
          <Rect x={engine.paddle.x - 3} y={engine.paddle.y - 3} width={engine.paddle.width + 6} height={engine.paddle.height + 6} rx={8} fill="#FF6B6B" opacity={0.35} />
        )}
        {engine.activePowers.has('shield') && (
          <Rect x={0} y={engine.paddle.y - 6} width={CANVAS_WIDTH} height={engine.paddle.height + 12} rx={10} fill="#00FF88" opacity={0.15} />
        )}
        <Rect x={engine.paddle.x} y={engine.paddle.y} width={engine.paddle.width} height={engine.paddle.height} fill={Colors.primary} rx={6} ry={6} />
        <Rect x={engine.paddle.x + 2} y={engine.paddle.y + 1} width={engine.paddle.width - 4} height={3} fill="rgba(255,255,255,0.6)" rx={2} />

        {/* الكرة (مع نار بدون ارتداد من الطوب) */}
        {engine.balls.map((ball, i) => (
          <React.Fragment key={`ball-${i}`}>
            {ball.onFire && (
              <>
                <Circle cx={ball.x} cy={ball.y} r={ball.radius * 3} fill="#FF4500" opacity={0.2} />
                <Circle cx={ball.x} cy={ball.y} r={ball.radius * 2} fill="#FFD700" opacity={0.3} />
              </>
            )}
            <Circle cx={ball.x} cy={ball.y} r={ball.radius} fill={ball.onFire ? '#FFD700' : Colors.accent} stroke={ball.onFire ? '#FF4500' : 'white'} strokeWidth={ball.onFire ? 2 : 1} />
            <Circle cx={ball.x - ball.radius / 3} cy={ball.y - ball.radius / 3} r={ball.radius / 3} fill="rgba(255,255,255,0.8)" />
          </React.Fragment>
        ))}

        {/* القوى كصناديق غامضة */}
        {engine.powerUps.map((p, i) => renderMysteryBox(p, i))}

        {/* الجزيئات */}
        {engine.particles.map((p, i) => (
          <Circle key={`pt-${i}`} cx={p.x} cy={p.y} r={p.size} fill={p.color} opacity={p.life / 40} />
        ))}
      </Svg>
    );
  };

  return (
    <LinearGradient colors={['#0a0a1f', '#1a1a3e']} style={styles.container}>
      <StatusBar style="light" />

      {/* HUD */}
      <View style={styles.hud}>
        <TouchableOpacity onPress={handlePause}>
          <GlassCard style={styles.hudButton}>
            <Text style={styles.hudIcon}>||</Text>
          </GlassCard>
        </TouchableOpacity>

        <GlassCard style={styles.levelCard}>
          <Text style={styles.levelText}>{I18n.t('level')} {stats.level}</Text>
        </GlassCard>

        <GlassCard style={styles.scoreCard}>
          <Text style={styles.scoreLabel}>{I18n.t('score')}</Text>
          <Text style={styles.scoreValue}>{stats.score}</Text>
        </GlassCard>
      </View>

      {/* الأرواح */}
      <GlassCard style={styles.livesCard}>
        {Array.from({ length: 3 }).map((_, i) => (
          <View key={i} style={[styles.heart, i >= stats.lives && styles.heartLost]} />
        ))}
      </GlassCard>

      {/* شريط التقدم */}
      <GlassCard style={styles.progressCard}>
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: `${100 - (stats.bricksRemaining / (engineRef.current?.bricks.length || 1)) * 100}%` }]} />
        </View>
        <Text style={styles.bricksCount}>{stats.bricksRemaining} {I18n.t('bricksRemaining')}</Text>
      </GlassCard>

      {/* القوى النشطة */}
      {engineRef.current && engineRef.current.activePowers.size > 0 && (
        <View style={styles.activePowersContainer}>
          {Array.from(engineRef.current.activePowers).map((power, i) => (
            <View key={i} style={[styles.activePowerBadge, { 
              backgroundColor: 
                power === 'expand' ? '#4ECDC4' :
                power === 'shrink' ? '#FF6B6B' :
                power === 'slow' ? '#FFD93D' :
                power === 'fast' ? '#00FF88' :
                power === 'fire' ? '#FF4500' : '#9D50BB'
            }]}>
              <Text style={styles.activePowerText}>
                {power === 'expand' ? '↔ توسيع' :
                 power === 'shrink' ? '↕ تصغير' :
                 power === 'slow' ? '◷ بطيء' :
                 power === 'fast' ? '⚡ سريع' :
                 power === 'fire' ? '☄ نار' : '◎ متعدد'}
              </Text>
            </View>
          ))}
        </View>
      )}

      {/* Canvas */}
      <View style={styles.canvasContainer}>
        {renderGame()}
      </View>

      {/* إيقاف مؤقت */}
      {isPaused && (
        <View style={[styles.overlay, { opacity: overlayAnimation.opacity }]}>
          <GlassCard style={styles.overlayCard}>
            <Text style={[styles.overlayTitle, { transform: [{ scale: overlayAnimation.scale }] }]}>|| {I18n.t('paused')}</Text>
            <View style={styles.statsRow}>
              <Text style={styles.statText}>{I18n.t('level')}: {stats.level}</Text>
              <Text style={styles.statText}>{I18n.t('score')}: {stats.score}</Text>
            </View>
            <GlassButton title={I18n.t('resume')} icon="▶" variant="primary" onPress={handleResume} />
            <GlassButton title={I18n.t('mainMenu')} icon="◀" variant="secondary" onPress={onExit} />
          </GlassCard>
        </View>
      )}

      {/* فوز */}
      {showWin && (
        <View style={[styles.overlay, { opacity: overlayAnimation.opacity }]}>
          <GlassCard style={styles.overlayCard}>
            <View style={styles.celebrationIcon}>
              <Text style={styles.celebrationIconText}>✓</Text>
            </View>
            <Text style={styles.overlayTitle}>{I18n.t('levelComplete')}</Text>
            <View style={styles.winStats}>
              <Text style={styles.winStatText}>{I18n.t('level')}: {stats.level}</Text>
              <Text style={styles.winStatText}>{I18n.t('score')}: {stats.score}</Text>
            </View>
            <View style={styles.starsRow}>
              <View style={styles.starIcon}>
                <Text style={styles.starIconText}>★</Text>
              </View>
              <View style={styles.starIcon}>
                <Text style={styles.starIconText}>★</Text>
              </View>
              <View style={styles.starIcon}>
                <Text style={styles.starIconText}>★</Text>
              </View>
            </View>
            {stats.level < 20 ? (
              <GlassButton title={I18n.t('nextLevel')} icon="▶" variant="primary" onPress={handleNextLevel} />
            ) : (
              <GlassButton title={I18n.t('gameCompleted')} variant="primary" onPress={onExit} />
            )}
            <GlassButton title={I18n.t('mainMenu')} variant="secondary" onPress={onExit} />
          </GlassCard>
        </View>
      )}

      {/* خسارة */}
      {showLose && (
        <View style={[styles.overlay, { opacity: overlayAnimation.opacity }]}>
          <GlassCard style={styles.overlayCard}>
            <View style={styles.gameOverIcon}>
              <Text style={styles.gameOverIconText}>✗</Text>
            </View>
            <Text style={styles.overlayTitle}>{I18n.t('gameOver')}</Text>
            <View style={styles.winStats}>
              <Text style={styles.winStatText}>{I18n.t('finalScore')}: {stats.score}</Text>
              <Text style={styles.winStatText}>{I18n.t('reachedLevel')}: {stats.level}</Text>
            </View>
            <GlassButton title={I18n.t('tryAgain')} icon="↻" variant="primary" onPress={handleRetry} />
            <GlassButton title={I18n.t('mainMenu')} variant="secondary" onPress={onExit} />
          </GlassCard>
        </View>
      )}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  hud: { flexDirection: 'row', justifyContent: 'space-between', padding: Sizes.md, paddingTop: height * 0.06 },
  hudButton: { padding: Sizes.sm, minWidth: 44, alignItems: 'center', justifyContent: 'center' },
  hudIcon: { fontSize: 20, textAlign: 'center' },
  levelCard: { padding: Sizes.sm, paddingHorizontal: Sizes.md },
  levelText: { color: Colors.textPrimary, fontWeight: '700', fontSize: Sizes.fontMd },
  scoreCard: { padding: Sizes.sm, paddingHorizontal: Sizes.md, alignItems: 'flex-end' },
  scoreLabel: { fontSize: 10, color: Colors.textSecondary },
  scoreValue: { fontSize: 16, fontWeight: '700', color: Colors.primary },
  livesCard: { flexDirection: 'row', gap: Sizes.sm, alignSelf: 'center', padding: Sizes.sm, paddingHorizontal: Sizes.md, marginTop: Sizes.xs },
  heart: { 
    width: 20, 
    height: 20, 
    borderRadius: 10, 
    backgroundColor: Colors.danger 
  },
  heartLost: { opacity: 0.2 },
  progressCard: { alignSelf: 'center', width: '90%', padding: Sizes.sm, marginTop: Sizes.xs },
  progressBar: { height: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 10, overflow: 'hidden', marginBottom: Sizes.xs },
  progressFill: { height: '100%', backgroundColor: Colors.success },
  bricksCount: { color: Colors.textSecondary, fontSize: 11, textAlign: 'center' },
  activePowersContainer: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: Sizes.xs, paddingHorizontal: Sizes.md, marginTop: Sizes.xs },
  activePowerBadge: { paddingHorizontal: Sizes.sm, paddingVertical: 4, borderRadius: 15, borderWidth: 2, borderColor: 'white' },
  activePowerText: { color: 'white', fontSize: 11, fontWeight: '700' },
  canvasContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: Sizes.md },
  overlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.85)', justifyContent: 'center', alignItems: 'center', padding: Sizes.xl },
  overlayCard: { width: '100%', maxWidth: 350, padding: Sizes.xl, alignItems: 'center' },
  overlayTitle: { fontSize: Sizes.fontXxl, fontWeight: '900', color: Colors.textPrimary, marginBottom: Sizes.md, textAlign: 'center' },
  celebration: { fontSize: 72, marginBottom: Sizes.sm },
  gameOverIcon: { 
    width: 72, 
    height: 72, 
    marginBottom: Sizes.sm,
    borderRadius: 36,
    backgroundColor: Colors.danger,
    justifyContent: 'center',
    alignItems: 'center',
  },
  gameOverIconText: {
    color: 'white',
    fontSize: 40,
    fontWeight: 'bold',
  },
  celebrationIcon: { 
    width: 72, 
    height: 72, 
    marginBottom: Sizes.sm,
    borderRadius: 36,
    backgroundColor: Colors.success,
    justifyContent: 'center',
    alignItems: 'center',
  },
  celebrationIconText: {
    color: 'white',
    fontSize: 40,
    fontWeight: 'bold',
  },
  statsRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-around', marginBottom: Sizes.lg },
  statText: { color: Colors.textSecondary, fontSize: Sizes.fontMd },
  winStats: { width: '100%', gap: Sizes.sm, marginBottom: Sizes.lg },
  winStatText: { color: Colors.primary, fontSize: Sizes.fontLg, fontWeight: '700', textAlign: 'center' },
  starsRow: { flexDirection: 'row', gap: Sizes.sm, marginBottom: Sizes.xl },
  star: { fontSize: 32 },
  starIcon: { 
    width: 32, 
    height: 32, 
    borderRadius: 16,
    backgroundColor: Colors.warning,
    justifyContent: 'center',
    alignItems: 'center',
  },
  starIconText: {
    color: 'white',
    fontSize: 20,
  },
});