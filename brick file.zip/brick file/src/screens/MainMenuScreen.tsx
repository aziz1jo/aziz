// src/screens/MainMenuScreen.tsx

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import GlassButton from '../components/GlassButton';
import GlassCard from '../components/GlassCard';
import Storage from '../utils/storage';
import I18n from '../utils/i18n';
import { Colors, Sizes } from '../utils/theme';

const { width, height } = Dimensions.get('window');

interface MainMenuScreenProps {
  onStartGame: () => void;
  onShowLevels: () => void;
  onShowHowToPlay: () => void;
  onShowSettings: () => void;
}

export default function MainMenuScreen({ 
  onStartGame, 
  onShowLevels, 
  onShowHowToPlay,
  onShowSettings 
}: MainMenuScreenProps) {
  const [highScore, setHighScore] = useState(0);
  const [highLevel, setHighLevel] = useState(1);
  const [logoAnimation, setLogoAnimation] = useState({ scale: 1, opacity: 1 });
  
  useEffect(() => {
    // رسوم متحركة بسيطة للشعار عند تحميل الشاشة
    setLogoAnimation({ scale: 0.9, opacity: 0.8 });
    setTimeout(() => {
      setLogoAnimation({ scale: 1, opacity: 1 });
    }, 300);
  }, []);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const score = await Storage.getHighScore();
      const level = await Storage.getHighLevel();
      setHighScore(score);
      setHighLevel(level);
    } catch (error) {
      console.log('Error loading stats:', error);
    }
  };

  return (
    <LinearGradient colors={['#0a0a1f', '#1a1a3e']} style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.content}>
        {/* شعار اللعبة */}
        <View style={styles.logoContainer}>
          <Text style={[styles.logo, { transform: [{ scale: logoAnimation.scale }], opacity: logoAnimation.opacity }]}>BRICK</Text>
          <Text style={[styles.logo, { transform: [{ scale: logoAnimation.scale }], opacity: logoAnimation.opacity }]}>BREAKER</Text>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>3D</Text>
          </View>
        </View>

        {/* الأزرار */}
        <View style={styles.buttonsContainer}>
          <GlassButton
            title={I18n.t('startGame')}
            icon="▶"
            variant="primary"
            onPress={onStartGame}
            style={{ transform: [{ scale: logoAnimation.scale }] }}
          />
          
          <View style={styles.buttonRow}>
            <GlassButton
              title={I18n.t('levels')}
              icon="◼"
              variant="secondary"
              onPress={onShowLevels}
              style={styles.halfButton}
            />
            
            <GlassButton
              title={I18n.t('settings')}
              icon="⚙"
              variant="secondary"
              onPress={onShowSettings}
              style={styles.halfButton}
            />
          </View>

          <GlassButton
            title={I18n.t('howToPlay')}
            icon="?"
            variant="secondary"
            onPress={onShowHowToPlay}
          />
        </View>

        {/* الإحصائيات */}
        <View style={styles.statsContainer}>
          <GlassCard style={styles.statCard}>
            <View style={styles.statIconContainer}>
              <Text style={styles.statIconText}>T</Text>
            </View>
            <Text style={styles.statValue}>{highScore}</Text>
            <Text style={styles.statLabel}>{I18n.t('highScore')}</Text>
          </GlassCard>

          <GlassCard style={styles.statCard}>
            <View style={styles.statIconContainer}>
              <Text style={styles.statIconText}>L</Text>
            </View>
            <Text style={styles.statValue}>{highLevel}</Text>
            <Text style={styles.statLabel}>{I18n.t('highLevel')}</Text>
          </GlassCard>
        </View>

        <Text style={styles.version}>v1.0.0</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    justifyContent: 'space-evenly',
    padding: Sizes.lg,
    paddingTop: height * 0.08,
    paddingBottom: Sizes.xl,
  },
  logoContainer: {
    alignItems: 'center',
  },
  logo: {
    fontSize: 42,
    fontWeight: '900',
    color: Colors.primary,
    textShadowColor: Colors.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
    letterSpacing: 2,
  },
  badge: {
    backgroundColor: Colors.glass,
    borderWidth: 2,
    borderColor: Colors.primary,
    borderRadius: Sizes.radiusRound,
    paddingHorizontal: Sizes.md,
    paddingVertical: 4,
    marginTop: Sizes.sm,
  },
  badgeText: {
    color: Colors.primary,
    fontSize: Sizes.fontSm,
    fontWeight: '700',
    letterSpacing: 2,
  },
  buttonsContainer: {
    gap: Sizes.sm,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: Sizes.sm,
  },
  halfButton: {
    flex: 1,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: Sizes.md,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    padding: Sizes.md,
    gap: 4,
  },
  statIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.glass,
    borderWidth: 2,
    borderColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 5,
  },
  statIconText: {
    color: Colors.primary,
    fontSize: 24,
    fontWeight: 'bold',
    textShadowColor: Colors.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 8,
  },
  statLabel: {
    color: Colors.textSecondary,
    fontSize: Sizes.fontXs,
    textAlign: 'center',
  },
  statValue: {
    color: Colors.primary,
    fontSize: Sizes.fontXl,
    fontWeight: '700',
  },
  version: {
    textAlign: 'center',
    color: Colors.textSecondary,
    fontSize: 10,
    opacity: 0.4,
  },
});