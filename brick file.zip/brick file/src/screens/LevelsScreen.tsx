// src/screens/LevelsScreen.tsx

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import GlassButton from '../components/GlassButton';
import GlassCard from '../components/GlassCard';
import Storage from '../utils/storage';
import { Colors, Sizes } from '../utils/theme';

interface LevelsScreenProps {
  onSelectLevel: (level: number) => void;
  onBack: () => void;
}

export default function LevelsScreen({ onSelectLevel, onBack }: LevelsScreenProps) {
  const [highLevel, setHighLevel] = useState(1);
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);
  const [levelStars, setLevelStars] = useState<{ [key: number]: number }>({});
  const [buttonAnimation, setButtonAnimation] = useState<{ [key: number]: { scale: number } }>({});

  const totalLevels = 20;

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const level = await Storage.getHighLevel();
    const completed = await Storage.getCompletedLevels();
    const stars = await Storage.getLevelStars();
    
    setHighLevel(level);
    setCompletedLevels(completed);
    setLevelStars(stars);
  };

  const renderLevel = (levelNum: number) => {
    const isUnlocked = levelNum <= highLevel;
    const isCompleted = completedLevels.includes(levelNum);
    const stars = levelStars[levelNum] || 0;

    return (
      <TouchableOpacity
        key={levelNum}
        disabled={!isUnlocked}
        onPress={() => {
          // تأثير ضغط خفيف
          setButtonAnimation({ ...buttonAnimation, [levelNum]: { scale: 0.95 } });
          setTimeout(() => {
            setButtonAnimation({ ...buttonAnimation, [levelNum]: { scale: 1 } });
          }, 150);
          onSelectLevel(levelNum);
        }}
        style={[
          styles.levelItem,
          isUnlocked && styles.levelUnlocked,
          isCompleted && styles.levelCompleted,
          { transform: [{ scale: buttonAnimation[levelNum]?.scale || 1 }] }
        ]}
      >
        {isUnlocked ? (
          <>
            <Text style={styles.levelNumber}>{levelNum}</Text>
            <View style={styles.starsContainer}>
              <View style={[styles.starContainer, stars >= 1 && styles.starEarned]}>
                <Text style={styles.starIcon}>★</Text>
              </View>
              <View style={[styles.starContainer, stars >= 2 && styles.starEarned]}>
                <Text style={styles.starIcon}>★</Text>
              </View>
              <View style={[styles.starContainer, stars >= 3 && styles.starEarned]}>
                <Text style={styles.starIcon}>★</Text>
              </View>
            </View>
          </>
        ) : (
          <View style={styles.lockContainer}>
            <Text style={styles.lockIcon}>◈</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <LinearGradient colors={['#0a0a1f', '#1a1a3e']} style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <Text style={styles.title}>اختر المستوى</Text>
      </View>

      <ScrollView 
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.levelsGrid}>
          {Array.from({ length: totalLevels }, (_, i) => renderLevel(i + 1))}
        </View>

        <GlassButton
          title="عودة"
          icon="◀"
          variant="secondary"
          onPress={onBack}
          style={styles.backButton}
        />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: Sizes.xxl * 2,
    paddingHorizontal: Sizes.xl,
    paddingBottom: Sizes.lg,
  },
  title: {
    fontSize: Sizes.fontXxl,
    fontWeight: '900',
    color: Colors.primary,
    textAlign: 'center',
    textShadowColor: Colors.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  content: {
    padding: Sizes.xl,
  },
  levelsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Sizes.md,
    marginBottom: Sizes.xl,
  },
  levelItem: {
    width: '22%',
    aspectRatio: 1,
    backgroundColor: Colors.glass,
    borderWidth: 2,
    borderColor: Colors.glassBorder,
    borderRadius: Sizes.radiusMd,
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 0.3,
  },
  levelUnlocked: {
    opacity: 1,
    borderColor: Colors.primary,
  },
  levelCompleted: {
    backgroundColor: 'rgba(0, 255, 136, 0.1)',
    borderColor: Colors.success,
  },
  levelNumber: {
    fontSize: Sizes.fontXl,
    fontWeight: '700',
    color: Colors.textPrimary,
    marginBottom: Sizes.xs,
  },
  starsContainer: {
    flexDirection: 'row',
    gap: 2,
  },
  starContainer: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  starEarned: {
    backgroundColor: Colors.warning,
  },
  starIcon: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
  },
  lockContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  lockIcon: {
    color: Colors.textSecondary,
    fontSize: Sizes.fontLg,
  },
  backButton: {
    marginTop: Sizes.lg,
  },
});