// src/screens/HowToPlayScreen.tsx

import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { StatusBar } from 'expo-status-bar';
import GlassButton from '../components/GlassButton';
import GlassCard from '../components/GlassCard';
import { Colors, Sizes } from '../utils/theme';

interface HowToPlayScreenProps {
  onBack: () => void;
}

export default function HowToPlayScreen({ onBack }: HowToPlayScreenProps) {
  const instructions = [
    { icon: '↔', title: 'التحكم', desc: 'اسحب بإصبعك لتحريك المضرب يميناً ويساراً' },
    { icon: '◎', title: 'الهدف', desc: 'حطم جميع الطوب لإكمال المستوى' },
    { icon: '♥', title: 'الأرواح', desc: 'لديك 3 أرواح - لا تدع الكرة تسقط' },
    { icon: '★', title: 'النجوم', desc: 'احصل على 3 نجوم بإنهاء المستوى بدون خسارة' },
  ];

  const powers = [
    { emoji: '↔', name: 'توسيع', color: '#4ECDC4' },
    { emoji: '◷', name: 'بطيء', color: '#FFD93D' },
    { emoji: '⚡', name: 'سريع', color: '#FF6B6B' },
    { emoji: '☄', name: 'نار', color: '#FF4500' },
    { emoji: '◎', name: 'متعدد', color: '#9D50BB' },
    { emoji: '⊞', name: 'درع', color: '#00ff88' },
    { emoji: '◆', name: 'نقاط×2', color: '#FFD700' },
    { emoji: '✦', name: 'انفجار', color: '#FF1493' },
  ];

  return (
    <LinearGradient colors={['#0a0a1f', '#1a1a3e']} style={styles.container}>
      <StatusBar style="light" />
      
      <View style={styles.header}>
        <Text style={styles.title}>كيف تلعب</Text>
      </View>

      <ScrollView 
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* التعليمات */}
        {instructions.map((item, index) => (
          <GlassCard key={index} style={styles.instructionCard}>
            <Text style={styles.instructionIcon}>{item.icon}</Text>
            <View style={styles.instructionText}>
              <Text style={styles.instructionTitle}>{item.title}</Text>
              <Text style={styles.instructionDesc}>{item.desc}</Text>
            </View>
          </GlassCard>
        ))}

        {/* القوى الخاصة */}
        <Text style={styles.sectionTitle}>القوى الخاصة</Text>
        <View style={styles.powersGrid}>
          {powers.map((power, index) => (
            <GlassCard 
              key={index} 
              style={styles.powerItem}
              glow
              glowColor={power.color}
            >
              <Text style={styles.powerEmoji}>{power.emoji}</Text>
              <Text style={styles.powerName}>{power.name}</Text>
            </GlassCard>
          ))}
        </View>

        <GlassButton
          title="عودة"
          icon="◀"
          variant="primary"
          onPress={onBack}
          style={styles.backButton}
        />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: Sizes.xxl * 2,
    paddingHorizontal: Sizes.xl,
    paddingBottom: Sizes.lg,
  },
  title: {
    fontSize: Sizes.fontXxl,
    fontWeight: '900',
    color: Colors.primary,
    textAlign: 'center',
    textShadowColor: Colors.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  content: {
    padding: Sizes.xl,
  },
  instructionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Sizes.md,
    marginBottom: Sizes.md,
    padding: Sizes.lg,
  },
  instructionIcon: {
    fontSize: 40,
  },
  instructionText: {
    flex: 1,
  },
  instructionTitle: {
    fontSize: Sizes.fontLg,
    fontWeight: '700',
    color: Colors.primary,
    marginBottom: Sizes.xs,
  },
  instructionDesc: {
    fontSize: Sizes.fontMd,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
  sectionTitle: {
    fontSize: Sizes.fontXl,
    fontWeight: '700',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginTop: Sizes.xl,
    marginBottom: Sizes.lg,
  },
  powersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Sizes.md,
    marginBottom: Sizes.xl,
  },
  powerItem: {
    width: '22%',
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  powerEmoji: {
    fontSize: 24,
    marginBottom: Sizes.xs,
  },
  powerName: {
    fontSize: Sizes.fontXs,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  backButton: {
    marginTop: Sizes.lg,
  },
});