// src/utils/storage.ts

import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  HIGH_SCORE: 'bb3d_highScore',
  HIGH_LEVEL: 'bb3d_highLevel',
  COMPLETED_LEVELS: 'bb3d_completedLevels',
  LEVEL_STARS: 'bb3d_levelStars',
  TOTAL_STARS: 'bb3d_totalStars',
  GAME_COMPLETED: 'bb3d_gameCompleted',
  
  // إعدادات جديدة
  SOUND_ENABLED: 'bb3d_soundEnabled',
  MUSIC_VOLUME: 'bb3d_musicVolume',
  VIBRATION_ENABLED: 'bb3d_vibrationEnabled',
  VIBRATION_INTENSITY: 'bb3d_vibrationIntensity',
  LANGUAGE: 'bb3d_language',
  DIFFICULTY: 'bb3d_difficulty',
};

export type Difficulty = 'easy' | 'medium' | 'hard';

class StorageManager {
  async save(key: string, value: any) {
    try {
      const jsonValue = JSON.stringify(value);
      await AsyncStorage.setItem(key, jsonValue);
    } catch (e) {
      console.error('Error saving data:', e);
    }
  }

  async load(key: string, defaultValue: any = null) {
    try {
      const jsonValue = await AsyncStorage.getItem(key);
      return jsonValue != null ? JSON.parse(jsonValue) : defaultValue;
    } catch (e) {
      console.error('Error loading data:', e);
      return defaultValue;
    }
  }

  async remove(key: string) {
    try {
      await AsyncStorage.removeItem(key);
    } catch (e) {
      console.error('Error removing data:', e);
    }
  }

  async clearAll() {
    try {
      await AsyncStorage.clear();
    } catch (e) {
      console.error('Error clearing data:', e);
    }
  }

  // Game Data
  async saveHighScore(score: number) {
    await this.save(KEYS.HIGH_SCORE, score);
  }

  async getHighScore(): Promise<number> {
    return await this.load(KEYS.HIGH_SCORE, 0);
  }

  async saveHighLevel(level: number) {
    await this.save(KEYS.HIGH_LEVEL, level);
  }

  async getHighLevel(): Promise<number> {
    return await this.load(KEYS.HIGH_LEVEL, 1);
  }

  async saveCompletedLevels(levels: number[]) {
    await this.save(KEYS.COMPLETED_LEVELS, levels);
  }

  async getCompletedLevels(): Promise<number[]> {
    return await this.load(KEYS.COMPLETED_LEVELS, []);
  }

  async saveLevelStars(stars: { [key: number]: number }) {
    await this.save(KEYS.LEVEL_STARS, stars);
  }

  async getLevelStars(): Promise<{ [key: number]: number }> {
    return await this.load(KEYS.LEVEL_STARS, {});
  }

  async saveTotalStars(stars: number) {
    await this.save(KEYS.TOTAL_STARS, stars);
  }

  async getTotalStars(): Promise<number> {
    return await this.load(KEYS.TOTAL_STARS, 0);
  }

  async saveGameCompleted(completed: boolean) {
    await this.save(KEYS.GAME_COMPLETED, completed);
  }

  async getGameCompleted(): Promise<boolean> {
    return await this.load(KEYS.GAME_COMPLETED, false);
  }

  // Settings
  async saveSoundEnabled(enabled: boolean) {
    await this.save(KEYS.SOUND_ENABLED, enabled);
  }

  async getSoundEnabled(): Promise<boolean> {
    return await this.load(KEYS.SOUND_ENABLED, true);
  }

  async saveMusicVolume(volume: number) {
    await this.save(KEYS.MUSIC_VOLUME, volume);
  }

  async getMusicVolume(): Promise<number> {
    return await this.load(KEYS.MUSIC_VOLUME, 0.7);
  }

  async saveVibrationEnabled(enabled: boolean) {
    await this.save(KEYS.VIBRATION_ENABLED, enabled);
  }

  async getVibrationEnabled(): Promise<boolean> {
    return await this.load(KEYS.VIBRATION_ENABLED, true);
  }

  async saveVibrationIntensity(intensity: number) {
    await this.save(KEYS.VIBRATION_INTENSITY, intensity);
  }

  async getVibrationIntensity(): Promise<number> {
    return await this.load(KEYS.VIBRATION_INTENSITY, 1.0);
  }

  async saveLanguage(language: string) {
    await this.save(KEYS.LANGUAGE, language);
  }

  async getLanguage(): Promise<string> {
    return await this.load(KEYS.LANGUAGE, 'ar');
  }

  async saveDifficulty(difficulty: Difficulty) {
    await this.save(KEYS.DIFFICULTY, difficulty);
  }

  async getDifficulty(): Promise<Difficulty> {
    return await this.load(KEYS.DIFFICULTY, 'medium');
  }
}

export default new StorageManager();