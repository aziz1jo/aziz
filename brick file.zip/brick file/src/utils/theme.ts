// src/utils/theme.ts

export const Colors = {
  // Cyber Neon Colors
  primary: '#00f0ff',
  secondary: '#ff00ff',
  accent: '#ffff00',
  success: '#00ff88',
  danger: '#ff0055',
  warning: '#ffd93d',
  
  // Glass Effect
  glass: 'rgba(255, 255, 255, 0.05)',
  glassBorder: 'rgba(255, 255, 255, 0.1)',
  glassShadow: 'rgba(0, 0, 0, 0.3)',
  
  // Background
  bgPrimary: '#0a0a1f',
  bgSecondary: '#1a1a3e',
  
  // Text
  textPrimary: '#ffffff',
  textSecondary: 'rgba(255, 255, 255, 0.7)',
  
  // Brick Colors (6 variations)
  bricks: [
    ['#00f0ff', '#0080ff'],
    ['#ff00ff', '#ff0080'],
    ['#ffff00', '#ffd700'],
    ['#00ff88', '#00cc66'],
    ['#ff6b6b', '#ff4444'],
    ['#9d50bb', '#7b2cbf'],
  ],
  
  // Power-ups
  powers: {
    expand: '#4ECDC4',
    slow: '#FFD93D',
    fast: '#FF6B6B',
    fire: '#FF4500',
    multi: '#9D50BB',
    shield: '#00ff88',
    double: '#FFD700',
    bomb: '#FF1493',
  }
};

export const Shadows = {
  small: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 4,
  },
  large: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.44,
    shadowRadius: 10.32,
    elevation: 8,
  },
  glow: (color: string) => ({
    shadowColor: color,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 15,
    elevation: 10,
  }),
};

export const Sizes = {
  // Spacing
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  
  // Border Radius
  radiusSm: 8,
  radiusMd: 12,
  radiusLg: 16,
  radiusXl: 24,
  radiusRound: 50,
  
  // Font Sizes
  fontXs: 12,
  fontSm: 14,
  fontMd: 16,
  fontLg: 20,
  fontXl: 24,
  fontXxl: 32,
  fontTitle: 48,
};