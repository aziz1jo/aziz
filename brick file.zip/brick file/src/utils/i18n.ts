// src/utils/i18n.ts

export const translations = {
  ar: {
    // القائمة الرئيسية
    gameTitle: 'BRICK BREAKER',
    subtitle: '3D ULTRA',
    startGame: 'ابدأ اللعبة',
    continue: 'متابعة',
    levels: 'المستويات',
    howToPlay: 'كيف تلعب',
    settings: 'الإعدادات',
    highScore: 'أعلى نقاط',
    highLevel: 'أعلى مستوى',
    
    // الإعدادات
    settingsTitle: 'الإعدادات',
    sound: 'الصوت',
    music: 'الموسيقى',
    vibration: 'الاهتزاز',
    volume: 'مستوى الصوت',
    language: 'اللغة',
    difficulty: 'مستوى الصعوبة',
    easy: 'سهل',
    medium: 'متوسط',
    hard: 'صعب',
    back: 'عودة',
    
    // شاشة اللعبة
    level: 'مستوى',
    score: 'النقاط',
    paused: 'متوقف مؤقتاً',
    resume: 'متابعة',
    restart: 'إعادة البدء',
    mainMenu: 'القائمة الرئيسية',
    bricksRemaining: 'طوبة متبقية',
    
    // شاشة الفوز
    levelComplete: 'مستوى مكتمل!',
    yourScore: 'النقاط',
    nextLevel: 'المستوى التالي',
    gameCompleted: 'أكملت اللعبة!',
    
    // شاشة الخسارة
    gameOver: 'انتهت اللعبة',
    finalScore: 'النقاط النهائية',
    reachedLevel: 'وصلت للمستوى',
    tryAgain: 'حاول مرة أخرى',
    
    // كيف تلعب
    howToPlayTitle: 'كيف تلعب',
    control: 'التحكم',
    controlDesc: 'اسحب بإصبعك لتحريك المضرب يميناً ويساراً',
    objective: 'الهدف',
    objectiveDesc: 'حطم جميع الطوب لإكمال المستوى',
    lives: 'الأرواح',
    livesDesc: 'لديك 3 أرواح - لا تدع الكرة تسقط',
    stars: 'النجوم',
    starsDesc: 'احصل على 3 نجوم بإنهاء المستوى بدون خسارة',
    powerUps: 'القوى الخاصة',
    
    // المستويات
    selectLevel: 'اختر المستوى',
    locked: 'مقفل',
    
    // القوى
    expand: 'توسيع',
    slow: 'بطيء',
    fire: 'نار',
    multi: 'متعدد',
    shield: 'درع',
  },
  
  en: {
    // Main Menu
    gameTitle: 'BRICK BREAKER',
    subtitle: '3D ULTRA',
    startGame: 'Start Game',
    continue: 'Continue',
    levels: 'Levels',
    howToPlay: 'How to Play',
    settings: 'Settings',
    highScore: 'High Score',
    highLevel: 'High Level',
    
    // Settings
    settingsTitle: 'Settings',
    sound: 'Sound',
    music: 'Music',
    vibration: 'Vibration',
    volume: 'Volume',
    language: 'Language',
    difficulty: 'Difficulty',
    easy: 'Easy',
    medium: 'Medium',
    hard: 'Hard',
    back: 'Back',
    
    // Game Screen
    level: 'Level',
    score: 'Score',
    paused: 'Paused',
    resume: 'Resume',
    restart: 'Restart',
    mainMenu: 'Main Menu',
    bricksRemaining: 'Bricks Left',
    
    // Win Screen
    levelComplete: 'Level Complete!',
    yourScore: 'Score',
    nextLevel: 'Next Level',
    gameCompleted: 'Game Completed!',
    
    // Lose Screen
    gameOver: 'Game Over',
    finalScore: 'Final Score',
    reachedLevel: 'Reached Level',
    tryAgain: 'Try Again',
    
    // How to Play
    howToPlayTitle: 'How to Play',
    control: 'Control',
    controlDesc: 'Swipe to move the paddle left and right',
    objective: 'Objective',
    objectiveDesc: 'Break all bricks to complete the level',
    lives: 'Lives',
    livesDesc: 'You have 3 lives - don\'t let the ball fall',
    stars: 'Stars',
    starsDesc: 'Get 3 stars by completing without losing lives',
    powerUps: 'Power Ups',
    
    // Levels
    selectLevel: 'Select Level',
    locked: 'Locked',
    
    // Powers
    expand: 'Expand',
    slow: 'Slow',
    fire: 'Fire',
    multi: 'Multi',
    shield: 'Shield',
  }
};

export type Language = 'ar' | 'en';

class I18n {
  private currentLanguage: Language = 'ar';
  
  setLanguage(lang: Language) {
    this.currentLanguage = lang;
  }
  
  getLanguage(): Language {
    return this.currentLanguage;
  }
  
  t(key: string): string {
    const keys = key.split('.');
    let value: any = translations[this.currentLanguage];
    
    for (const k of keys) {
      value = value?.[k];
    }
    
    return value || key;
  }
  
  isRTL(): boolean {
    return this.currentLanguage === 'ar';
  }
}

export default new I18n();