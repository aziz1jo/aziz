// src/utils/audio.ts

import { Audio } from 'expo-av';
import * as Haptics from 'expo-haptics';
import Storage from './storage';

class AudioManager {
  private isSoundEnabled: boolean = true;
  private isVibrationEnabled: boolean = true;
  private vibrationIntensity: number = 1.0;
  private musicVolume: number = 0.7;

  async initialize() {
    try {
      await Audio.setAudioModeAsync({
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldDuckAndroid: true,
      });
      
      this.isSoundEnabled = await Storage.getSoundEnabled();
      this.isVibrationEnabled = await Storage.getVibrationEnabled();
      this.vibrationIntensity = await Storage.getVibrationIntensity();
      this.musicVolume = await Storage.getMusicVolume();
      
      console.log('Audio Manager Initialized ✅');
    } catch (error) {
      console.log('Audio init error:', error);
    }
  }

  // تشغيل نغمة بسيطة باستخدام الاهتزاز + صوت محاكي
  private async playBeep(frequency: number, duration: number) {
    if (!this.isSoundEnabled) return;
    
    try {
      // محاكاة صوت بسيط
      // يمكن استبدالها بملفات MP3 لاحقاً
      const soundObject = new Audio.Sound();
      
      // للتجربة السريعة نستخدم الاهتزاز فقط
      // لأن إنشاء أصوات ديناميكية يحتاج ملفات
    } catch (error) {
      console.log('Beep error:', error);
    }
  }

  async playPaddleHit() {
    this.vibrate('light');
    if (this.isSoundEnabled) {
      // صوت خفيف
      this.playBeep(400, 50);
    }
  }

  async playBrickHit() {
    this.vibrate('medium');
    if (this.isSoundEnabled) {
      this.playBeep(600, 80);
    }
  }

  async playBrickBreak() {
    this.vibrate('heavy');
    if (this.isSoundEnabled) {
      // نغمة صاعدة
      setTimeout(() => this.vibrate('light'), 50);
      setTimeout(() => this.vibrate('light'), 100);
    }
  }

  async playPowerUp() {
    this.vibrate('success');
    if (this.isSoundEnabled) {
      // لحن قوة
      setTimeout(() => this.vibrate('light'), 80);
      setTimeout(() => this.vibrate('light'), 160);
      setTimeout(() => this.vibrate('medium'), 240);
    }
  }

  async playLoseLife() {
    this.vibrate('error');
    if (this.isSoundEnabled) {
      // اهتزازات متتالية للخسارة
      setTimeout(() => this.vibrate('error'), 150);
      setTimeout(() => this.vibrate('heavy'), 300);
    }
  }

  async playLevelWin() {
    this.vibrate('success');
    if (this.isSoundEnabled) {
      // لحن فوز
      setTimeout(() => this.vibrate('success'), 100);
      setTimeout(() => this.vibrate('success'), 200);
      setTimeout(() => this.vibrate('success'), 300);
      setTimeout(() => this.vibrate('success'), 400);
    }
  }

  async playGameOver() {
    this.vibrate('error');
    if (this.isSoundEnabled) {
      // نمط هزيمة
      setTimeout(() => this.vibrate('error'), 200);
      setTimeout(() => this.vibrate('heavy'), 400);
      setTimeout(() => this.vibrate('heavy'), 600);
    }
  }

  vibrate(type: 'light' | 'medium' | 'heavy' | 'success' | 'error' | 'warning') {
    if (!this.isVibrationEnabled || this.vibrationIntensity === 0) return;

    try {
      // احتمالية الاهتزاز حسب الشدة
      const shouldVibrate = Math.random() < this.vibrationIntensity;
      if (!shouldVibrate && this.vibrationIntensity < 1.0) return;

      switch (type) {
        case 'light':
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          break;
        case 'medium':
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          break;
        case 'heavy':
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
          break;
        case 'success':
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          break;
        case 'error':
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          break;
        case 'warning':
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          break;
      }
    } catch (error) {
      // تجاهل الأخطاء
    }
  }

  async toggleSound() {
    this.isSoundEnabled = !this.isSoundEnabled;
    await Storage.saveSoundEnabled(this.isSoundEnabled);
    if (this.isSoundEnabled) {
      this.vibrate('success');
    }
    return this.isSoundEnabled;
  }

  async toggleVibration() {
    this.isVibrationEnabled = !this.isVibrationEnabled;
    await Storage.saveVibrationEnabled(this.isVibrationEnabled);
    if (this.isVibrationEnabled) {
      this.vibrate('success');
    }
    return this.isVibrationEnabled;
  }

  async setMusicVolume(volume: number) {
    this.musicVolume = Math.max(0, Math.min(1, volume));
    await Storage.saveMusicVolume(this.musicVolume);
  }

  async setVibrationIntensity(intensity: number) {
    this.vibrationIntensity = Math.max(0, Math.min(1, intensity));
    await Storage.saveVibrationIntensity(this.vibrationIntensity);
    if (intensity > 0) {
      this.vibrate('medium');
    }
  }

  getSoundEnabled() {
    return this.isSoundEnabled;
  }

  getVibrationEnabled() {
    return this.isVibrationEnabled;
  }

  getVibrationIntensity() {
    return this.vibrationIntensity;
  }

  getMusicVolume() {
    return this.musicVolume;
  }

  async cleanup() {
    // تنظيف الموارد
  }
}

export default new AudioManager();